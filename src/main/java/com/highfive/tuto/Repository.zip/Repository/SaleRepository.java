package com.highfive.tuto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.highfive.tuto.domain.Sale;
import com.highfive.tuto.domain.Car;
public interface SaleRepository extends JpaRepository<Sale, Long>{

    Optional<Sale> findByNameByCar(String Name , Car car);
    
}
