package com.highfive.tuto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.highfive.tuto.domain.Brand;
import com.highfive.tuto.domain.Car;
import com.highfive.tuto.domain.Model;
import com.highfive.tuto.domain.Engine;
import com.highfive.tuto.domain.Feature;

public interface CarRepository  extends JpaRepository<Car, Long>{
    
    boolean existsByNameAndBrand(String Name , Brand brand , Model model);

    Optional<Car> findByNameByBrandByModel(String Name , Brand brand , Model model);

    Optional<Car> findByNameByEngine(String Name , Engine engine);
    Optional<Car> findByNameByFeature(String Name , Feature feature);
    
}
