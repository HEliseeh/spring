package com.highfive.tuto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.highfive.tuto.domain.Brand;

public interface BrandRepository extends JpaRepository<Brand, Long> {
    
    boolean existsByName(String name);
    // fais en quelque sorte une requette select if exist et renvoi true of false

    Optional<Brand> findByName(String name);
    // fais un select et le mot clé optional evite de retourner une erreur si il ne trouve pas l'element
    
}
